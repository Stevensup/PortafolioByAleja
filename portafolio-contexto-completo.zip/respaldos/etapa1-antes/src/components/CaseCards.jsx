import { useState } from 'react'
import { cases } from '../data/cases'
import { useLang, Rich } from '../lib/i18n'
import { setAccent } from '../lib/accent'
import { goTo } from '../lib/transition'
import { Phone, Poster } from './Mockups'
import { inkOn } from '../lib/color'

// Las cartas: abanico en desktop (la del centro más alta), carrusel con snap en celular.
function CardBody({ c, d, open }) {
  return (
    <>
      <div className="flex items-start justify-between gap-3 p-6 pb-0">
        <div>
          <p className="text-[12px] tracking-[.08em] uppercase text-white/55">{d.type}</p>
          <h3 className="mt-2 text-[44px] leading-none tracking-[-0.05em]">{c.name}</h3>
        </div>
        <span className="text-[13px] text-white/50 tabular-nums">{c.year}</span>
      </div>
      <div className="relative flex-1 grid place-items-center overflow-hidden px-6 pt-6">
        <div className="absolute inset-x-8 bottom-0 h-2/3 rounded-full blur-3xl opacity-60" style={{ background: c.accent }} aria-hidden="true" />
        {c.kind === 'brand'
          ? <Poster src={c.cover} accent={c.accent} name={c.name} label={d.type} className="relative w-[64%] rounded-xl shadow-2xl rotate-[-4deg]" />
          : <Phone src={c.cover} accent={c.accent} label={c.name} className="relative w-[56%] translate-y-[14%] shadow-2xl" />}
      </div>
      <div className="flex items-center justify-between gap-3 p-6 border-t border-white/10 bg-ink/70 backdrop-blur-md relative">
        <p className="text-[14px] text-white/70 leading-snug line-clamp-2">{d.tagline}</p>
        <span className="shrink-0 w-11 h-11 rounded-full grid place-items-center" style={{ background: c.accent, color: inkOn(c.accent) }} aria-hidden="true">→</span>
      </div>
      <span className="sr-only">{open}</span>
    </>
  )
}

export default function CaseCards() {
  const { t, lang } = useLang()
  const [hover, setHover] = useState(-1)
  const n = cases.length, mid = (n - 1) / 2
  const pick = i => { setHover(i); setAccent(i < 0 ? null : cases[i].accent) }
  const open = (e, c) => { e.preventDefault(); goTo(c.slug, e.currentTarget, c.accent) }

  return (
    <section id="trabajo" className="relative py-20 md:py-28 scroll-mt-20">
      <div className="wrap">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-10 md:mb-4">
          <div>
            <p className="eyebrow">{t.cards.eyebrow}</p>
            <h2 className="display h-lg mt-5"><Rich text={t.cards.title} /></h2>
          </div>
          <p className="text-white/55 max-w-[30ch] text-[15px]"><span className="hidden md:inline">{t.cards.hint}</span><span className="md:hidden">{t.cards.hintTouch}</span></p>
        </div>

        {/* Desktop: abanico */}
        <div className="hidden md:block relative h-[640px] lg:h-[680px]" onMouseLeave={() => pick(-1)}>
          {cases.map((c, i) => {
            const k = i - mid, active = hover === i, other = hover >= 0 && !active
            const push = other ? Math.sign(i - hover) * 70 : 0
            const tf = active
              ? `translate(-50%, -50%) translateX(${k * 300}px) translateY(-46px) rotate(0deg) scale(1.07)`
              : `translate(-50%, -50%) translateX(${k * 300 + push}px) translateY(${Math.abs(k) * 34 - (k === 0 ? 20 : 0)}px) rotate(${k * 9}deg) scale(${other ? .96 : 1})`
            const d = c[lang]
            return (
              <a key={c.slug} href={'#' + c.slug} data-cursor={t.cards.open}
                onMouseEnter={() => pick(i)} onFocus={() => pick(i)} onBlur={() => pick(-1)} onClick={e => open(e, c)}
                className="absolute left-1/2 top-1/2 w-[340px] lg:w-[370px] h-[520px] lg:h-[560px] flex flex-col rounded-[24px] overflow-hidden border bg-surface"
                style={{ transform: tf, zIndex: active ? 10 : 5 - Math.abs(k), transition: 'transform .7s cubic-bezier(.16,1,.3,1), box-shadow .6s, border-color .6s',
                  borderColor: active ? c.accent : 'rgba(255,255,255,.08)', boxShadow: active ? `0 30px 120px -20px ${c.accent}88` : '0 30px 60px -30px rgba(0,0,0,.8)' }}>
                <CardBody c={c} d={d} open={t.cards.open} />
              </a>
            )
          })}
        </div>

        {/* Celular: carrusel con snap */}
        <div className="md:hidden -mx-5 px-5 flex gap-4 overflow-x-auto snap-x snap-mandatory pb-4 [scrollbar-width:none]" aria-label={t.cards.eyebrow}>
          {cases.map(c => (
            <a key={c.slug} href={'#' + c.slug} onClick={e => open(e, c)} onTouchStart={() => setAccent(c.accent)}
              className="snap-center shrink-0 w-[82vw] max-w-[360px] h-[500px] flex flex-col rounded-[24px] overflow-hidden border border-white/10 bg-surface">
              <CardBody c={c} d={c[lang]} open={t.cards.open} />
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
