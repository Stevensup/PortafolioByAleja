# Ivra · caso de estudio

Página del caso Ivra para el portafolio de Aleja Moreno. Usa la opción sin build del BRIEF: un `index.html` con CSS y JS vanilla, más GSAP ScrollTrigger y Lenis desde CDN.

## Cómo correrlo
Abre `index.html` con un servidor local (por ejemplo `npx serve .`) o súbelo tal cual a Vercel o Netlify.

## Dónde tocar
| Qué | Dónde |
|---|---|
| Textos (copiados de `CONTENIDO.md`) | `index.html`, cada sección marcada con un comentario `<!-- 01 · Hero -->`, etc. |
| Colores, tipografía, radios | `css/ivra.css`, bloque `:root` |
| El punto que viaja con el scroll | `js/ivra.js`, función `target()`. Un keyframe por sección. |
| Transición marca → app (sección 08) | `js/ivra.js`, función `render08()` |
| Imágenes | `img/` (WebP optimizado desde `assets/`) |
| Capturas de las 5 pantallas | `pantallas/` (sacadas del prototipo con Playwright) |
| Prototipo jugable | `prototipo/index.html` (copia sin cambios) |

## Pendientes
- `[AÑO]` en el hero: falta el año real del proyecto.
- Enlaces del cierre: hoy apuntan al portafolio (`#proyectos` y `#contacto`).
