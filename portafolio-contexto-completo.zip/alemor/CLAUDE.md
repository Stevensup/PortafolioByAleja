# Portafolio de Alejandra Moreno · Instrucciones para Claude

Diseñadora gráfica y UX/UI (Bogotá). El portafolio busca vacantes de diseño UI/producto. Un reclutador debe entender en 10 segundos quién es y llegar a los casos con un clic.

## Reglas de trabajo (no negociables)

1. **No reconstruyas el proyecto.** Edita solo lo necesario, en el archivo y la sección que toca.
2. **No cambies animaciones GSAP ni Lenis sin pedir permiso.** Esto incluye tiempos, easing, ScrollTrigger, pins y el punto que viaja en Ivra.
3. **Respeta la identidad de cada proyecto.** Cada caso tiene su color y sus reglas; no los mezcles ni los "unifiques".
4. **Trabaja por secciones.** Una sección a la vez; muestra el resultado antes de seguir.
5. **Pregunta antes de tocar** algo que la persona no pidió, aunque parezca una mejora.
6. **No publiques datos privados.** El correo de trabajo no va en el sitio; usa el que esté en `src/data/site.js`.

## Mapa del portafolio

| Qué | Dónde | Enlace publicado |
|---|---|---|
| Home (React) | `/home/user/alemor/` (esta carpeta) | https://claude.ai/artifact/YJTEaRSG1YnHR7VLffyKBC |
| Caso Ivra (HTML + GSAP + Lenis) | `/home/user/portafolio/ivra/` | https://claude.ai/artifact/FjNjRFv1uiDRrFF2ENNtVZ |
| Material original de Ivra | `/home/user/ivra-src/ivra-portafolio/` (tiene su propio `CLAUDE.md`, `BRIEF.md` y `CONTENIDO.md`: no los modifiques) | — |
| Versión antigua de la home | `/home/user/portafolio/index.html` (ya no se usa) | — |

Casos actuales: **Ivra, Relevo y Nubla**. Patitas se eliminó: no lo vuelvas a agregar.

## Home en React: dónde está cada cosa

- **Contenido (lo primero que debes tocar):** `src/data/site.js` (textos ES/EN, correo, links, CV) y `src/data/cases.js` (casos, colores, cifras, imágenes).
- `*palabra*` en un texto = serif itálica. Una imagen en `null` dibuja un mockup de relleno. `// RELLENO` marca lo provisional.
- Páginas: `src/pages/Home.jsx`, `src/pages/CaseStudy.jsx` (plantilla de 8 láminas).
- Secciones: `src/components/` (Hero, CaseCards, DiagonalWall, Services, Process, About, Contact, Nav, Loader, Cursor, Background, Mockups).
- Utilidades: `src/lib/` (`accent.js` color activo, `color.js` contraste, `router.js` rutas por hash, `motion.js` GSAP/Lenis, `transition.js` paso entre páginas, `i18n.jsx` idioma).
- Rutas por hash: `#ivra` abre un caso; `#trabajo`, `#sobre-mi`, `#proceso` y `#contacto` bajan a la sección.

## Sistema visual

**Concepto:** un mundo oscuro que cambia de luz con cada caso.

**Home (identidad de Alejandra):**
- **El negro profundo domina.** Fondo `#0A0A0A` · superficies `#141414` · bordes `rgba(255,255,255,.08)` · texto `#F5F5F5` · gris `#8A8A8A`.
- **Naranja `#FF7A2C` y rosado `#E4336A` son acentos estratégicos**, no fondos: CTA principal, palabra clave de un titular, estado activo, punto o detalle que guía la mirada. Nunca como relleno de secciones completas.
- Glow y luces difusas de la home solo en naranja y rosado, siempre sutiles: la base debe verse negra y elegante.
- **No mezcles automáticamente los colores de los proyectos en la home.** El color de un caso solo aparece mientras ese caso está activo (hover o foco en su carta, o su página) y al salir vuelve el negro con naranja y rosado.
- Verifica contraste AA: el rosado sobre negro no alcanza 4,5:1 en texto pequeño, así que úsalo en texto grande, en elementos no textuales o en su tono aclarado (como hace `textTone()`).

**Implementación del color:**
- Acentos de los casos: Ivra `#A6F56B` · Relevo `#2B4BFF` · Nubla `#FF5A1F`.
- El color activo se aplica con `setAccent()` (variables `--accent`, `--accent-text`, `--accent-ink`, `--g1..--g3`). No pongas colores fijos en los componentes.
- Para texto en color usa `--accent-text` (ya cumple contraste AA). Para texto sobre un relleno de acento usa `--accent-ink`.
- Tipografía: Inter Tight para todo; Instrument Serif itálica solo para la palabra clave de un titular. Titulares grandes, peso regular, tracking apretado.
- Tarjetas: radio de 16 a 24 px, borde de 1 px, glow suave del acento activo.

**Identidad propia de cada caso:**
- **Ivra:** respeta sus tokens y reglas (`/home/user/portafolio/ivra/css/ivra.css` y el `BRIEF.md` original): fondo noche `#120F1E`, rosa `#FF3FA4` = lo que hace la persona, menta `#3DFFB6` = lo que hizo la IA, nunca juntos en un elemento. Unbounded + Geist. Sin glows ni partículas. No inventes métricas: es un proyecto conceptual.
- **Relevo:** azul eléctrico, cálido y confiable. Su contenido aún es de relleno.
- **Nubla:** naranja incandescente, marca premium (afiches en pared acanalada). Su contenido aún es de relleno.

## Calidad mínima

- Responsive real: 390 px, tablet y desktop, sin scroll horizontal de la página.
- Accesible: contraste AA, navegable con teclado, foco visible, `alt` en español, un solo `<h1>` por página.
- `prefers-reduced-motion` respetado en todo.
- Imágenes en WebP de menos de 300 KB, con `width` y `height` para no mover el contenido al cargar.
- Nada de 3D pesado ni WebGL.

## Eficiencia de tokens y contexto

1. **No explores todo el proyecto** al comenzar. Identifica primero qué archivo o sección corresponde a lo pedido.
2. **Empieza por los datos.** Si el cambio es de texto, color o imagen, edita `src/data/` y no abras componentes.
3. **Lee solo lo necesario.** Ubica con `grep` o Glob y lee el rango de líneas que necesitas. Si hace falta revisar más archivos, explica primero por qué.
4. **No releas** archivos cuyo contenido ya conoces y no ha cambiado, ni los que acabas de editar.
5. **No reconstruyas** componentes, animaciones o funcionalidades que ya funcionan. Edita con reemplazos puntuales (Edit), no con reescrituras completas.
6. **Evita herramientas, comandos y búsquedas que no aporten.** No delegues a subagentes lo que se resuelve con pocas búsquedas.
7. **Verifica lo justo:** un build o una captura al final de cada sección, no después de cada cambio, y solo de la sección tocada, en desktop y celular.
8. **Trabajos grandes por etapas pequeñas.** Espera aprobación antes de pasar a cambios importantes. Ante una duda de diseño, pregunta en una línea en vez de construir varias opciones.
9. **Al terminar, informa brevemente** qué archivos modificaste y qué quedó pendiente. No repitas análisis, explicaciones, resúmenes ni código ya mostrados, salvo que te lo pidan.

## Correr y publicar

- `npm run dev` (puerto 5173) · `npm run build` genera `dist/`.
- Para publicar la home como Artifact: `npm run build`, luego `node scripts-artifact.mjs` (crea `dist/artifact.html`), y publicar ese archivo en el enlace de la home con los archivos de `dist/assets`, `dist/img` y `dist/prototipo`.
- El caso Ivra se publica desde `/home/user/portafolio/ivra/index.html`. Ese archivo no lleva `<!doctype html>` porque Artifacts lo agrega: si se abre localmente sin él, Lenis no hace scroll (modo quirks). Para probarlo localmente, sírvelo con el doctype agregado.
- El entorno es temporal y estas carpetas no son un repositorio de Git: guarda o sube los cambios importantes.

## Pendientes conocidos

- Correo real, CV en PDF y perfiles de LinkedIn y Behance (`src/data/site.js`).
- Año de Ivra (aparece como `[AÑO]` en el caso y `2025` provisional en la home).
- Textos, imágenes y cifras reales de Relevo y Nubla.
- Ajuste de colores de la home: la regla ya está definida en "Sistema visual", pero el código aún no la aplica (hoy la home mezcla los tres colores de los casos en `setAccent(null)` y el fondo). Requiere aprobación antes de tocar el sitio.
