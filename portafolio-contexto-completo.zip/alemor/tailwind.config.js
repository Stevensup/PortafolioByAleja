/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0A0A', surface: '#141414', fg: '#F5F5F5', mute: '#8A8A8A',
        line: 'rgba(255,255,255,0.08)', accent: 'rgb(var(--accent-rgb) / <alpha-value>)'
      },
      fontFamily: {
        sans: ['"Inter Tight"', 'system-ui', 'sans-serif'],
        serif: ['"Instrument Serif"', 'Georgia', 'serif']
      },
      borderRadius: { card: '20px' }
    }
  },
  plugins: []
}
