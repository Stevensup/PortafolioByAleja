import { createRoot } from 'react-dom/client'
import App from './App'
import { setAccent } from './lib/accent'
import './index.css'

setAccent(null)
createRoot(document.getElementById('root')).render(<App />)
