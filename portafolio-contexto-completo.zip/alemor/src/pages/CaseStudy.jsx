import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { cases } from '../data/cases'
import { useLang, Rich } from '../lib/i18n'
import { setAccent } from '../lib/accent'
import { goTo } from '../lib/transition'
import { gsap, reduced } from '../lib/motion'
import { inkOn } from '../lib/color'
import { Phone, Poster, Pic } from '../components/Mockups'

// Plantilla de caso inspirada en un manual de marca: 8 láminas con encabezado fijo.
const SHEETS = ['portada', 'reto', 'investigacion', 'decisiones', 'diseno', 'cifras', 'piezas', 'resultado']

function Sheet({ id, i, children, className = '' }) {
  return <section id={'l-' + id} data-sheet={i} className={'relative py-20 md:py-28 ' + className}>{children}</section>
}
function Head({ eyebrow, title }) {
  return (<><p className="eyebrow rv">{eyebrow}</p><h2 className="display h-lg mt-5 max-w-[18ch] rv"><Rich text={title} /></h2></>)
}

function Wall({ c, items, captions = [], tall }) {
  return (
    <div className={'fluted rounded-[28px] overflow-hidden px-6 md:px-14 ' + (tall ? 'py-16 md:py-24' : 'py-12 md:py-16')}>
      <div className="relative grid grid-cols-3 gap-4 md:gap-10 items-start">
        {items.map((src, i) => (
          <figure key={i} className={'m-0 float-y ' + (i === 1 ? 'mt-10' : '')} style={{ '--d': i * .6 + 's' }}>
            <div className="relative mx-auto w-px h-8 md:h-12 bg-white/25" aria-hidden="true" />
            <Poster src={src} accent={c.accent} name={c.name} label={captions[i] || c.name} variant={i} className="rounded-md shadow-[0_40px_60px_-20px_rgba(0,0,0,.9)] ring-8 ring-[#e9e4dc]/90" alt={captions[i] || ''} />
            {captions[i] && <figcaption className="mt-4 text-center text-[12px] tracking-[.08em] uppercase text-white/55">{captions[i]}</figcaption>}
          </figure>
        ))}
      </div>
    </div>
  )
}

export default function CaseStudy({ c }) {
  const { t, lang } = useLang()
  const d = c[lang], ui = t.caseUi
  const idx = cases.indexOf(c), next = cases[(idx + 1) % cases.length]
  const [sheet, setSheet] = useState(0)
  const root = useRef(null)

  useEffect(() => { setAccent(c.accent); return () => setAccent(null) }, [c])
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && setSheet(+e.target.dataset.sheet)), { rootMargin: '-45% 0px -50% 0px' })
    root.current.querySelectorAll('[data-sheet]').forEach(s => io.observe(s))
    return () => io.disconnect()
  }, [c])
  useLayoutEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      gsap.from('.cover-in', { y: 40, opacity: 0, duration: 1, stagger: .08, ease: 'power3.out', delay: .35 })
      gsap.from('.cover-phone', { y: 120, rotate: -2, opacity: 0, duration: 1.4, ease: 'expo.out', delay: .4 })
      gsap.utils.toArray('.rv').forEach(el => gsap.from(el, { y: 30, opacity: 0, duration: .9, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%', once: true } }))
      gsap.utils.toArray('.par').forEach((el, i) => gsap.fromTo(el, { y: 60 + (i % 3) * 30 }, { y: -(40 + (i % 3) * 30), ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } }))
      if (root.current.querySelector('.diag')) gsap.fromTo('.diag', { xPercent: -6 }, { xPercent: -22, ease: 'none', scrollTrigger: { trigger: '.diag', start: 'top bottom', end: 'bottom top', scrub: .6 } })
    }, root)
    return () => ctx.revert()
  }, [c, lang])

  const metaRows = [[ui.meta.role, d.role], [ui.meta.year, c.year], [ui.meta.type, d.type], [ui.meta.deliverables, d.deliverables]]
  const pad = n => String(n).padStart(2, '0')

  return (
    <main ref={root} className="pb-10">
      {/* Encabezado fijo tipo lámina */}
      <div className="fixed left-0 right-0 z-40 bg-ink/70 backdrop-blur-xl border-b border-white/10" style={{ top: 'calc(env(safe-area-inset-top, 0px) + 64px)' }}>
        <div className="wrap h-11 flex items-center justify-between gap-4 text-[12px] tracking-[.06em] uppercase">
          <a href="#trabajo" className="text-white/60 hover:text-white shrink-0">← {ui.back}</a>
          <p className="truncate text-white/70"><b className="font-medium text-white">{c.name}</b><span className="hidden sm:inline"> · {d.type}</span> · {c.year}</p>
          <p className="tabular-nums shrink-0" aria-live="polite"><span className="text-white/50 hidden sm:inline">{ui.sheet} </span><span className="accent-text">{pad(sheet + 1)}</span><span className="text-white/40">/{pad(SHEETS.length)}</span></p>
        </div>
      </div>

      {/* 01 Portada */}
      <Sheet id="portada" i={0} className="!pt-40 md:!pt-48 min-h-[100svh] flex items-center">
        <div className="wrap w-full grid gap-12 md:grid-cols-[1.1fr_1fr] items-center">
          <div>
            <p className="eyebrow cover-in">{d.type}</p>
            <h1 className="display h-xl mt-6 cover-in"><Rich text={d.headline} /></h1>
            <p className="mt-6 text-[clamp(18px,1.7vw,22px)] text-white/70 max-w-[42ch] cover-in">{d.tagline}</p>
            <dl className="mt-10 grid grid-cols-2 gap-x-6 gap-y-5 border-t border-white/10 pt-6 cover-in">
              {metaRows.map(([k, v]) => <div key={k}><dt className="text-[12px] tracking-[.08em] uppercase text-white/45">{k}</dt><dd className="m-0 mt-1 text-[15px]">{v}</dd></div>)}
            </dl>
          </div>
          <div className="relative grid place-items-center min-h-[460px] md:min-h-[640px]">
            <div className="absolute w-[80%] aspect-square rounded-full blur-[90px] opacity-70" style={{ background: c.accent }} aria-hidden="true" />
            <div className="absolute w-[56%] aspect-square rounded-full border border-white/15" aria-hidden="true" />
            {c.kind === 'brand'
              ? <div className="cover-phone relative w-full"><Wall c={c} items={c.screens.slice(0, 3)} captions={[]} /></div>
              : <Phone src={c.cover} accent={c.accent} label={c.name} alt={d.tagline} className="cover-phone relative w-[min(300px,64vw)] rotate-[-12deg] shadow-[0_60px_120px_-30px_rgba(0,0,0,.9)]" />}
          </div>
        </div>
      </Sheet>

      {/* 02 Reto */}
      <Sheet id="reto" i={1}>
        <div className="wrap">
          <Head eyebrow={ui.sections.challenge} title={d.challenge.title} />
          <p className="mt-8 text-[clamp(17px,1.5vw,20px)] text-white/70 max-w-[62ch] leading-relaxed rv">{d.challenge.text}</p>
          <div className="mt-14 grid gap-4 md:grid-cols-3">
            {d.challenge.points.map(([h, p]) => <article key={h} className="card card-glow p-7 rv"><h3 className="text-[20px] font-medium">{h}</h3><p className="mt-3 text-white/65 leading-relaxed">{p}</p></article>)}
          </div>
        </div>
      </Sheet>

      {/* 03 Investigación */}
      <Sheet id="investigacion" i={2}>
        <div className="wrap">
          <Head eyebrow={ui.sections.research} title={d.research.title} />
          <p className="mt-8 text-[clamp(17px,1.5vw,20px)] text-white/70 max-w-[62ch] rv">{d.research.text}</p>
          <div className="mt-14 grid gap-4 md:grid-cols-[1.4fr_1fr]">
            <div className="card p-7 md:p-9 rv">
              <p className="inline-block text-[12px] tracking-[.08em] uppercase border border-dashed border-white/30 rounded-lg px-3 py-1.5 text-white/70">{d.research.label}</p>
              <ul className="mt-6 grid gap-5 list-none p-0">{d.research.bullets.map(b => <li key={b} className="flex gap-4 text-white/80 leading-relaxed"><span className="mt-2 w-2 h-2 rounded-full bg-accent shrink-0" aria-hidden="true" />{b}</li>)}</ul>
            </div>
            <div className="card card-glow p-7 md:p-9 rv">
              <p className="text-[12px] tracking-[.08em] uppercase text-white/45">Persona</p>
              <h3 className="display text-[40px] mt-3">{d.research.persona.name}</h3>
              <p className="mt-2 text-white/60">{d.research.persona.about}</p>
              <dl className="mt-6 grid gap-4">{[[lang === 'es' ? 'Quiere' : 'Wants', d.research.persona.wants], [lang === 'es' ? 'La frena' : 'Blocked by', d.research.persona.blocks]].map(([k, v]) => <div key={k}><dt className="text-[12px] tracking-[.08em] uppercase accent-text">{k}</dt><dd className="m-0 mt-1 text-white/80">{v}</dd></div>)}</dl>
            </div>
          </div>
        </div>
      </Sheet>

      {/* 04 Decisiones */}
      <Sheet id="decisiones" i={3}>
        <div className="wrap">
          <Head eyebrow={ui.sections.decisions} title={d.decisions.title} />
          <ol className="mt-14 list-none p-0 border-t border-white/10">
            {d.decisions.items.map(([h, p], i) => (
              <li key={h} className="grid md:grid-cols-[120px_1fr_1fr] gap-3 md:gap-8 py-8 border-b border-white/10 rv">
                <span className="text-[14px] tabular-nums accent-text">{pad(i + 1)}</span>
                <h3 className="display text-[clamp(22px,2.4vw,32px)] leading-tight">{h}</h3>
                <p className="text-white/65 leading-relaxed">{p}</p>
              </li>
            ))}
          </ol>
        </div>
      </Sheet>

      {/* 05 Diseño */}
      <Sheet id="diseno" i={4} className="overflow-hidden">
        <div className="wrap">
          <Head eyebrow={ui.sections.design} title={d.design.title} />
          <p className="mt-8 text-[clamp(17px,1.5vw,20px)] text-white/70 max-w-[56ch] rv">{d.design.text}</p>
        </div>
        {c.kind === 'brand' ? (
          <div className="wrap mt-14"><Wall c={c} items={c.screens} captions={d.design.captions} tall /></div>
        ) : (
          <>
            <div className="wrap mt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5 md:gap-6 items-start">
              {c.screens.map((s, i) => (
                <figure key={i} className={'m-0 par ' + (i > 2 ? 'hidden lg:block' : '') + (i === 2 ? ' hidden sm:block' : '')}>
                  <Phone src={s} accent={c.accent} label={d.design.captions[i]} alt={d.design.captions[i]} className="shadow-[0_40px_80px_-30px_rgba(0,0,0,.9)]" />
                  <figcaption className="mt-4 text-[13px] text-white/60">{pad(i + 1)} · {d.design.captions[i]}</figcaption>
                </figure>
              ))}
            </div>
            <div className="relative mt-24 h-[360px] md:h-[460px]" aria-hidden="true">
              <div className="diag absolute left-0 top-1/2 -translate-y-1/2 rotate-[-15deg] flex gap-5 w-max">
                {[...c.screens, ...c.screens, ...c.screens].map((s, i) => <Phone key={i} src={s} accent={c.accent} className="!h-[300px] md:!h-[380px] w-auto shrink-0" />)}
              </div>
            </div>
          </>
        )}
      </Sheet>

      {/* 06 Cifras */}
      <Sheet id="cifras" i={5}>
        <div className="wrap grid gap-px sm:grid-cols-2 lg:grid-cols-4 rounded-[24px] overflow-hidden border border-white/10 bg-white/10">
          {d.stats.map(([v, l]) => (
            <div key={l} className="bg-ink/90 p-7 md:p-9 min-h-[170px] md:min-h-[240px] flex flex-col justify-between rv">
              <b className="display font-normal text-[clamp(64px,7vw,112px)] accent-text">{v}</b>
              <span className="text-white/60 leading-snug max-w-[24ch]">{l}</span>
            </div>
          ))}
        </div>
      </Sheet>

      {/* 07 Piezas: bento */}
      <Sheet id="piezas" i={6}>
        <div className="wrap">
          <p className="eyebrow rv">{ui.sections.pieces}</p>
          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-3 md:gap-4">
            {c.gallery.map((g, i) => {
              const span = { tall: 'row-span-2', wide: 'col-span-2 row-span-2', sq: '', full: 'col-span-2 md:col-span-4 row-span-2' }[g.size] || ''
              return (
                <figure key={i} className={'relative m-0 rounded-[20px] overflow-hidden border border-white/10 group rv ' + span}>
                  <Pic src={g.src} accent={c.accent} label={g.label} alt={g.alt} imgClass="transition-transform duration-700 group-hover:scale-[1.03]" />
                  <figcaption className="absolute left-3 bottom-3 pill !py-1.5 !px-3 text-[11px] tracking-[.08em] uppercase bg-ink/70 backdrop-blur-md">{g.label}</figcaption>
                </figure>
              )
            })}
          </div>
        </div>
      </Sheet>

      {/* 08 Resultado + siguiente caso */}
      <Sheet id="resultado" i={7}>
        <div className="wrap">
          <Head eyebrow={ui.sections.result} title={d.result.title} />
          <p className="mt-8 display text-[clamp(24px,2.8vw,40px)] leading-tight max-w-[30ch] text-white/90 rv">{d.result.text}</p>
          <p className="mt-8 text-white/60 max-w-[62ch] leading-relaxed rv">{d.result.next}</p>
          {c.prototype && <a href={c.prototype} target="_blank" rel="noopener" className="btn btn-solid mt-10 rv">{lang === 'es' ? 'Probar el prototipo' : 'Try the prototype'} ↗</a>}

          <a href={'#' + next.slug} data-cursor={ui.next}
            onMouseEnter={() => setAccent(next.accent)} onMouseLeave={() => setAccent(c.accent)} onFocus={() => setAccent(next.accent)} onBlur={() => setAccent(c.accent)}
            onClick={e => { e.preventDefault(); goTo(next.slug, e.currentTarget, next.accent) }}
            className="group mt-24 grid md:grid-cols-[1fr_auto] items-end gap-8 rounded-[28px] overflow-hidden p-8 md:p-12 border border-white/10 relative"
            style={{ background: `radial-gradient(120% 140% at 100% 0%, ${next.accent}55, #141414 60%)` }}>
            <div className="relative">
              <p className="text-[12px] tracking-[.08em] uppercase text-white/60">{ui.next} · {next[lang].type}</p>
              <h2 className="display text-[clamp(64px,11vw,170px)] mt-3">{next.name}</h2>
              <p className="mt-2 text-white/70 max-w-[40ch]">{next[lang].tagline}</p>
            </div>
            <span className="relative w-20 h-20 rounded-full grid place-items-center text-[28px] transition-transform duration-500 group-hover:-rotate-45" style={{ background: next.accent, color: inkOn(next.accent) }} aria-hidden="true">→</span>
          </a>
        </div>
      </Sheet>
    </main>
  )
}
