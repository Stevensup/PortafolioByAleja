import { useEffect } from 'react'
import Hero from '../components/Hero'
import CaseCards from '../components/CaseCards'
import DiagonalWall from '../components/DiagonalWall'
import Services from '../components/Services'
import Process from '../components/Process'
import About from '../components/About'
import Contact from '../components/Contact'
import { setAccent } from '../lib/accent'

export default function Home() {
  useEffect(() => { setAccent(null) }, [])
  return (
    <main>
      <Hero />
      <CaseCards />
      <DiagonalWall />
      <Services />
      <Process />
      <About />
      <Contact />
    </main>
  )
}
