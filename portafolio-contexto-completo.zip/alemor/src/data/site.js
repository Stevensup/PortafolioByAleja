// ─────────────────────────────────────────────────────────────
//  TEXTOS GENERALES DEL SITIO (español / inglés)
//  Edita aquí sin tocar componentes. *palabra* = serif itálica.
//  Lo marcado con  // RELLENO  es contenido provisional.
// ─────────────────────────────────────────────────────────────

export const person = {
  name: 'Alejandra Moreno',
  short: 'Aleja',
  city: 'Bogotá, Colombia',
  email: 'tu-correo@ejemplo.com', // RELLENO: tu correo real
  photo: 'img/me/foto.webp',
  monogram: 'img/me/am.png',
  cv: '', // RELLENO: ruta a tu CV en PDF, por ejemplo 'cv/alejandra-moreno.pdf'
  links: [
    { label: 'LinkedIn', href: 'https://www.linkedin.com/' }, // RELLENO: tu perfil
    { label: 'Behance', href: 'https://www.behance.net/' } // RELLENO: tu perfil
  ]
}

export const site = {
  es: {
    nav: { work: 'Trabajo', about: 'Sobre mí', process: 'Proceso', contact: 'Contacto', cta: 'Hablemos', menu: 'Menú', close: 'Cerrar' },
    loader: 'Alejandra',
    hero: {
      // Cada pieza del titular. type: pill | fill | photo | icon | text | serif
      pieces: [
        { type: 'pill', text: 'Diseño' },
        { type: 'photo' },
        { type: 'fill', text: 'marcas' },
        { type: 'text', text: 'y apps' },
        { type: 'text', text: 'que' },
        { type: 'icon' },
        { type: 'serif', text: 'se sienten' },
        { type: 'pill', text: 'simples.' }
      ],
      cursors: ['Reclutador', 'Alejandra'],
      intro: 'Soy Alejandra, diseñadora UI/UX y de marca en Bogotá. Vengo de marketing digital y CRM: diseño pensando en negocio, datos y conversión.',
      tags: ['Branding', 'UI Design', 'UX', 'Motion'],
      metrics: [
        { value: '3', label: 'casos de producto y marca' },
        { value: '4+', label: 'años entre diseño y marketing' } // RELLENO: confirma tus años
      ],
      primary: 'Ver casos',
      secondary: 'Descargar CV'
    },
    cards: { eyebrow: 'Casos destacados', title: 'Tres proyectos, *tres* luces.', hint: 'Pasa el mouse por una carta. Haz clic para abrir el caso.', hintTouch: 'Desliza las cartas y toca una para abrir el caso.', open: 'Ver caso' },
    wall: { eyebrow: 'En la mesa', title: 'Pantallas, piezas y *sistemas*.' },
    services: { eyebrow: 'Qué hago', items: ['Branding', 'UI Design', 'UX Research', 'Motion', 'Web'] },
    process: {
      eyebrow: 'Proceso', title: 'Cómo *trabajo*.',
      steps: [
        { name: 'Entender', text: 'Negocio, usuarios y datos. Defino qué tiene que pasar para que el proyecto funcione.' },
        { name: 'Idear', text: 'Exploro rutas rápido, en papel y en Figma, antes de enamorarme de una.' },
        { name: 'Diseñar', text: 'Interfaces y marcas con sistema: componentes, tokens y reglas claras.' },
        { name: 'Probar', text: 'Prototipos navegables y pruebas con personas reales. Ajusto con lo que aprendo.' },
        { name: 'Entregar', text: 'Archivos ordenados, documentación y acompañamiento a desarrollo.' }
      ]
    },
    about: {
      eyebrow: 'Sobre mí', title: 'Diseño, marketing y *datos* en la misma mesa.',
      text: 'Empecé en marketing digital y CRM, midiendo qué hace que alguien abra, haga clic y vuelva. Aprendí UX/UI de forma empírica, construyendo productos. Por eso diseño interfaces que se ven bien y también cumplen un objetivo de negocio.',
      facts: [['Base', 'Bogotá · remoto'], ['Enfoque', 'UI, producto y marca'], ['Herramientas', 'Figma, Illustrator, Framer'], ['Idiomas', 'Español, inglés']]
    },
    contact: { eyebrow: 'Contacto', title: '¿Hablamos de tu *próximo* producto?', copy: 'Copiar correo', copied: 'Correo copiado', selected: 'Correo seleccionado: cópialo con Ctrl+C', marquee: ['Hablemos', "Let's talk"] },
    caseUi: {
      back: 'Todos los casos', next: 'Siguiente caso', sheet: 'Lámina',
      sections: { challenge: 'El reto', research: 'Investigación', decisions: 'Decisiones', design: 'Diseño', result: 'Resultado', pieces: 'Piezas clave' },
      meta: { role: 'Rol', year: 'Año', type: 'Tipo', deliverables: 'Entregables' }
    },
    footer: 'Diseñado y construido en Bogotá.',
    lang: 'EN'
  },
  en: {
    nav: { work: 'Work', about: 'About', process: 'Process', contact: 'Contact', cta: "Let's talk", menu: 'Menu', close: 'Close' },
    loader: 'Alejandra',
    hero: {
      pieces: [
        { type: 'pill', text: 'I design' },
        { type: 'photo' },
        { type: 'fill', text: 'brands' },
        { type: 'text', text: 'and apps' },
        { type: 'text', text: 'that' },
        { type: 'icon' },
        { type: 'serif', text: 'feel' },
        { type: 'pill', text: 'simple.' }
      ],
      cursors: ['Recruiter', 'Alejandra'],
      intro: "I'm Alejandra, a UI/UX and brand designer based in Bogotá. I come from digital marketing and CRM, so I design with business, data and conversion in mind.",
      tags: ['Branding', 'UI Design', 'UX', 'Motion'],
      metrics: [
        { value: '3', label: 'product and brand cases' },
        { value: '4+', label: 'years across design and marketing' }
      ],
      primary: 'See work',
      secondary: 'Download CV'
    },
    cards: { eyebrow: 'Selected work', title: 'Three projects, *three* lights.', hint: 'Hover a card. Click to open the case.', hintTouch: 'Swipe the cards and tap one to open it.', open: 'See case' },
    wall: { eyebrow: 'On the table', title: 'Screens, pieces and *systems*.' },
    services: { eyebrow: 'What I do', items: ['Branding', 'UI Design', 'UX Research', 'Motion', 'Web'] },
    process: {
      eyebrow: 'Process', title: 'How I *work*.',
      steps: [
        { name: 'Understand', text: 'Business, users and data. I define what has to happen for the project to work.' },
        { name: 'Ideate', text: 'I explore routes fast, on paper and in Figma, before falling for one.' },
        { name: 'Design', text: 'Interfaces and brands built as systems: components, tokens and clear rules.' },
        { name: 'Test', text: 'Clickable prototypes and tests with real people. I adjust with what I learn.' },
        { name: 'Deliver', text: 'Tidy files, documentation and close support for developers.' }
      ]
    },
    about: {
      eyebrow: 'About', title: 'Design, marketing and *data* at one table.',
      text: 'I started in digital marketing and CRM, measuring what makes people open, click and come back. I learned UX/UI hands-on, by building products. That is why my interfaces look good and also hit a business goal.',
      facts: [['Based in', 'Bogotá · remote'], ['Focus', 'UI, product and brand'], ['Tools', 'Figma, Illustrator, Framer'], ['Languages', 'Spanish, English']]
    },
    contact: { eyebrow: 'Contact', title: 'Shall we talk about your *next* product?', copy: 'Copy email', copied: 'Email copied', selected: 'Email selected: copy it with Ctrl+C', marquee: ["Let's talk", 'Hablemos'] },
    caseUi: {
      back: 'All work', next: 'Next case', sheet: 'Sheet',
      sections: { challenge: 'The challenge', research: 'Research', decisions: 'Decisions', design: 'Design', result: 'Outcome', pieces: 'Key pieces' },
      meta: { role: 'Role', year: 'Year', type: 'Type', deliverables: 'Deliverables' }
    },
    footer: 'Designed and built in Bogotá.',
    lang: 'ES'
  }
}

// Color de la home cuando ningún caso está activo: un degradado entre los acentos de los casos.
export const homeAccent = '#A6F56B'
