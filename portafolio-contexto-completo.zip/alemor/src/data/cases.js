// ─────────────────────────────────────────────────────────────
//  CASOS DEL PORTAFOLIO
//  Para agregar, quitar o reordenar casos, edita solo este archivo.
//  · *palabra*  → se muestra en serif itálica
//  · Imágenes: rutas dentro de /public (ej. 'img/ivra/inicio.webp').
//    Si una imagen es null, se dibuja un mockup de relleno con el color del caso.
//  · kind: 'app' (celulares y pantallas) o 'brand' (afiches en pared)
//  · Lo marcado con  // RELLENO  es provisional: reemplázalo con lo real.
// ─────────────────────────────────────────────────────────────

export const cases = [
  // ───────────────────────── IVRA (contenido real) ─────────────────────────
  {
    slug: 'ivra',
    name: 'Ivra',
    accent: '#A6F56B',
    kind: 'app',
    year: '2025', // RELLENO: confirma el año
    es: {
      type: 'Proyecto conceptual · Fintech',
      role: 'Estrategia de marca, UX y UI',
      deliverables: 'Marca, campaña, app y prototipo',
      tagline: 'Identidad y app de un banco digital cuya IA decide y actúa.',
      headline: 'Tu dinero va un paso *adelante*.',
      challenge: {
        title: 'Diseñar confianza en un banco que *actúa* solo.',
        text: 'Ivra es un banco digital cuya IA no sugiere: decide y actúa. Eso rompe el supuesto de toda app bancaria, donde cada movimiento lo inicia el usuario. El reto fue diseñar una experiencia en la que delegar tu dinero se sienta seguro.',
        points: [
          ['El problema', 'La banca digital quitó las filas, pero el trabajo sigue siendo tuyo: revisar, calcular, no olvidar.'],
          ['La idea', 'Un banco autónomo: tú pones las metas y le hablas; Ivra se adelanta y ejecuta.'],
          ['La tensión', 'Cuanto más hace la IA, menos control siente la persona. Todo el UX resuelve eso.']
        ]
      },
      research: {
        title: 'Nadie le entrega su plata a algo que *actúa* solo.',
        text: 'La pregunta de diseño dejó de ser cómo navegar y pasó a ser cómo confiar.',
        label: 'Hipótesis de partida (no son hallazgos)',
        bullets: [
          'La fricción no es la app, es la decisión. Transferir toma 20 segundos; decidir cuánto ahorrar toma semanas.',
          'Delegar da miedo si no ves el porqué. Aceptamos que un algoritmo elija la música, no que mueva la plata.',
          'El ingreso variable rompe el presupuesto. Quien factura distinto cada mes no puede planear con reglas fijas.'
        ],
        persona: { name: 'Mariana, 26', about: 'Diseñadora freelance, Bogotá, ingreso variable.', wants: 'Viajar el otro año sin dejar de pagar sus cuentas a tiempo.', blocks: 'Sentir que no sabe de finanzas y no confiar en algo automático.' }
      },
      decisions: {
        title: 'Cuatro decisiones y *por qué* las tomé.',
        items: [
          ['El nivel de autonomía va en el onboarding, no en ajustes', 'Escondido en un menú nadie lo tocaría y la IA se sentiría impuesta. Al entrar, el miedo se convierte en una decisión propia.'],
          ['Cada acción muestra su porqué antes que su monto', 'Con la cifra primero se lee como un cobro sorpresa. Con el motivo arriba, la misma acción se lee como un favor.'],
          ['Deshacer vive junto a la acción, no en el historial', 'La reversa tiene que estar donde aparece el susto. Si hay que buscarla, la confianza ya se rompió.'],
          ['Hablar reemplaza al formulario, pero deja rastro visible', 'Pedir en lenguaje natural es rápido e invisible. Por eso cada frase se vuelve una regla que se ve, se edita y se apaga.']
        ]
      },
      design: {
        title: 'Cinco pantallas que *sostienen* el concepto.',
        text: 'Rosa es lo que haces tú. Menta es lo que hizo Ivra. Nunca se mezclan en un mismo elemento.',
        captions: ['Nivel de autonomía', 'Inicio', 'Chat con Ivra', 'Detalle y deshacer', 'Metas']
      },
      result: {
        title: 'Lo que me *llevo*.',
        text: 'Cuando un producto decide por alguien, el diseño deja de ser navegación y pasa a ser confianza: explicar, acotar y dejar salida.',
        next: 'Qué probaría con usuarios: si al ver "Ivra actuó" la primera reacción es tranquilidad o alarma; qué nivel elige la gente y si lo sube con el tiempo; cuántos usan deshacer y por qué.'
      },
      stats: [
        ['24,7°', 'el ángulo del corte de la "i", el gesto de toda la marca'],
        ['3', 'niveles de autonomía que elige cada persona'],
        ['5', 'pantallas que sostienen el concepto'],
        ['10', 'nombres descartados antes de llegar a Ivra']
      ]
    },
    en: {
      type: 'Concept project · Fintech',
      role: 'Brand strategy, UX and UI',
      deliverables: 'Brand, campaign, app and prototype',
      tagline: 'Identity and app for a digital bank whose AI decides and acts.',
      headline: 'Your money is one step *ahead*.',
      challenge: {
        title: 'Designing trust in a bank that *acts* on its own.',
        text: 'Ivra is a digital bank whose AI does not suggest: it decides and acts. That breaks the core assumption of every banking app, where the user starts every move. The challenge was to make handing over your money feel safe.',
        points: [
          ['The problem', 'Digital banking removed the queues, but the work is still yours: checking, calculating, not forgetting.'],
          ['The idea', 'An autonomous bank: you set the goals and talk to it; Ivra gets ahead and executes.'],
          ['The tension', 'The more the AI does, the less in control people feel. The whole UX solves that.']
        ]
      },
      research: {
        title: 'Nobody hands their money to something that *acts* alone.',
        text: 'The design question stopped being how to navigate and became how to trust.',
        label: 'Starting hypotheses (not findings)',
        bullets: [
          'The friction is not the app, it is the decision. A transfer takes 20 seconds; deciding how much to save takes weeks.',
          'Delegating is scary if you cannot see why. We let an algorithm pick our music, not move our money.',
          'Variable income breaks budgets. If you bill differently every month you cannot plan with fixed rules.'
        ],
        persona: { name: 'Mariana, 26', about: 'Freelance designer, Bogotá, variable income.', wants: 'To travel next year without missing her bills.', blocks: 'Feeling she knows little about finance and not trusting automation.' }
      },
      decisions: {
        title: 'Four decisions and *why* I made them.',
        items: [
          ['Autonomy level lives in onboarding, not settings', 'Hidden in a menu nobody would touch it and the AI would feel imposed. At sign-up, fear becomes a choice.'],
          ['Every action shows its why before its amount', 'Amount first reads like a surprise charge. Reason first, the same action reads like a favor.'],
          ['Undo sits next to the action, not in history', 'The reversal has to be where the scare happens. If you have to look for it, trust is already gone.'],
          ['Talking replaces forms, but leaves a visible trail', 'Natural language is fast and invisible. So every phrase becomes a rule you can see, edit and switch off.']
        ]
      },
      design: {
        title: 'Five screens that *hold* the concept.',
        text: 'Pink is what you do. Mint is what Ivra did. They never share the same element.',
        captions: ['Autonomy level', 'Home', 'Chat with Ivra', 'Detail and undo', 'Goals']
      },
      result: {
        title: 'What I *take* away.',
        text: 'When a product decides for someone, design stops being navigation and becomes trust: explain, limit and leave a way out.',
        next: 'What I would test: whether "Ivra acted" brings calm or alarm; which level people choose and whether they raise it over time; how many use undo and why.'
      },
      stats: [
        ['24.7°', 'the angle of the "i" cut, the gesture of the whole brand'],
        ['3', 'autonomy levels each person chooses'],
        ['5', 'screens that hold the concept'],
        ['10', 'names discarded before landing on Ivra']
      ]
    },
    cover: 'img/ivra/inicio.webp',
    screens: ['img/ivra/autonomia.webp', 'img/ivra/inicio.webp', 'img/ivra/chat.webp', 'img/ivra/detalle.webp', 'img/ivra/metas.webp'],
    gallery: [
      { src: 'img/ivra/escultura-persona.webp', label: 'Instalación', alt: 'Mujer de perfil mirando una escultura del símbolo de Ivra con una esfera menta iluminada', size: 'tall' },
      { src: 'img/ivra/tarjeta-rostro.webp', label: 'Tarjeta', alt: 'Mujer joven sosteniendo la tarjeta negra de Ivra junto a su rostro, con luz rosa lateral', size: 'wide' },
      { src: 'img/ivra/smartwatch.webp', label: 'Wearable', alt: 'Reloj inteligente mostrando la notificación Ivra actuó más 12.400 pesos', size: 'tall' },
      { src: 'img/ivra/sobre.webp', label: 'Bienvenida', alt: 'Mano sosteniendo un sobre negro con el logo de Ivra y forro rosa', size: 'sq' },
      { src: 'img/ivra/gorra.webp', label: 'Merch', alt: 'Hombre joven con gorra negra bordada con el símbolo de Ivra, luz menta de fondo', size: 'sq' },
      { src: 'img/ivra/escultura-lector.webp', label: 'Lector', alt: 'Mano pasando la tarjeta de Ivra por un lector con forma del símbolo de la marca', size: 'sq' },
      { src: 'img/ivra/hoodie.webp', label: 'Merch', alt: 'Vista de espalda de un hombre con hoodie negro que dice Tu dinero va un paso adelante', size: 'sq' },
      { src: 'img/ivra/valla-noche.webp', label: 'Vía pública', alt: 'Valla nocturna con una mujer en bicicleta y el titular Tu plata se mueve sola, tú vives', size: 'full' }
    ],
    prototype: 'prototipo/ivra/index.html'
  },

  // ───────────────────────── RELEVO (relleno) ─────────────────────────
  {
    slug: 'relevo',
    name: 'Relevo',
    accent: '#2B4BFF',
    kind: 'app',
    year: '2025', // RELLENO
    es: {
      type: 'App · UX/UI',
      role: 'UX research y UI', // RELLENO
      deliverables: 'Investigación, flujos, app y bot de WhatsApp', // RELLENO
      tagline: 'La familia se organiza en la app; el adulto mayor participa por WhatsApp, sin instalar nada.',
      headline: 'Cuidar *juntos*, sin cargar a uno solo.',
      challenge: {
        title: 'El cuidado se cae cuando *todo* depende de una persona.', // RELLENO
        text: 'En muchas familias una sola persona coordina citas, medicamentos y visitas del adulto mayor. Relevo reparte esa carga entre todos y deja que el adulto mayor participe desde el canal que ya usa: WhatsApp.', // RELLENO
        points: [
          ['El problema', 'Una persona carga con todo y el resto se entera tarde.'], // RELLENO
          ['La idea', 'Turnos y tareas compartidas en una app, con el adulto mayor conectado por WhatsApp.'], // RELLENO
          ['La tensión', 'Coordinar más sin que el adulto mayor sienta que lo vigilan.'] // RELLENO
        ]
      },
      research: {
        title: 'Lo que *escuché* de las familias.', // RELLENO
        text: 'Resume aquí tu investigación: entrevistas, encuestas o pruebas.', // RELLENO
        label: 'Hallazgos', // RELLENO
        bullets: ['Hallazgo 1 de tu investigación.', 'Hallazgo 2 de tu investigación.', 'Hallazgo 3 de tu investigación.'], // RELLENO
        persona: { name: 'Persona, edad', about: 'Quién es y qué hace.', wants: 'Qué quiere lograr.', blocks: 'Qué la frena.' } // RELLENO
      },
      decisions: {
        title: 'Decisiones y *por qué*.', // RELLENO
        items: [
          ['WhatsApp como canal del adulto mayor', 'Explica por qué no instalar otra app fue clave.'], // RELLENO
          ['Turnos visibles para toda la familia', 'Explica la decisión.'], // RELLENO
          ['Recordatorios con confirmación simple', 'Explica la decisión.'] // RELLENO
        ]
      },
      design: { title: 'Pantallas *clave*.', text: 'Describe el sistema visual y las pantallas principales.', captions: ['Inicio familiar', 'Turnos', 'Chat de WhatsApp', 'Medicamentos'] }, // RELLENO
      result: { title: 'Resultado y *aprendizajes*.', text: 'Cuenta qué lograste y qué aprendiste.', next: 'Qué harías después.' }, // RELLENO
      stats: [['0', 'apps nuevas para el adulto mayor'], ['1', 'chat de WhatsApp para todo'], ['00', 'tu métrica real']] // RELLENO (la 3.ª)
    },
    en: {
      type: 'App · UX/UI',
      role: 'UX research and UI',
      deliverables: 'Research, flows, app and WhatsApp bot',
      tagline: 'The family organizes in the app; the older adult joins through WhatsApp, with nothing to install.',
      headline: 'Caring *together*, without one person carrying it all.',
      challenge: {
        title: 'Care breaks down when *everything* depends on one person.',
        text: 'In many families one person coordinates appointments, medication and visits. Relevo shares that load and lets the older adult take part from the channel they already use: WhatsApp.',
        points: [['The problem', 'One person carries it all and the rest find out late.'], ['The idea', 'Shared shifts and tasks in an app, with the older adult connected through WhatsApp.'], ['The tension', 'Coordinating more without the older adult feeling watched.']]
      },
      research: {
        title: 'What I *heard* from families.', text: 'Summarize your research here.', label: 'Findings',
        bullets: ['Finding 1.', 'Finding 2.', 'Finding 3.'],
        persona: { name: 'Persona, age', about: 'Who they are.', wants: 'What they want.', blocks: 'What stops them.' }
      },
      decisions: { title: 'Decisions and *why*.', items: [['WhatsApp as the older adult’s channel', 'Explain why no new app was key.'], ['Shifts visible to the whole family', 'Explain the decision.'], ['Reminders with simple confirmation', 'Explain the decision.']] },
      design: { title: 'Key *screens*.', text: 'Describe the visual system and main screens.', captions: ['Family home', 'Shifts', 'WhatsApp chat', 'Medication'] },
      result: { title: 'Outcome and *learnings*.', text: 'Tell what you achieved and learned.', next: 'What you would do next.' },
      stats: [['0', 'new apps for the older adult'], ['1', 'WhatsApp chat for everything'], ['00', 'your real metric']]
    },
    cover: null, // RELLENO: 'img/relevo/portada.webp'
    screens: [null, null, null, null], // RELLENO: capturas de la app
    gallery: [
      { src: null, label: 'App', alt: 'Pantalla de la app Relevo', size: 'tall' },
      { src: null, label: 'WhatsApp', alt: 'Conversación de WhatsApp con el adulto mayor', size: 'wide' },
      { src: null, label: 'Landing', alt: 'Landing de Relevo', size: 'sq' },
      { src: null, label: 'Redes', alt: 'Pieza para redes de Relevo', size: 'sq' }
    ]
  },

  // ───────────────────────── NUBLA (relleno) ─────────────────────────
  {
    slug: 'nubla',
    name: 'Nubla',
    accent: '#FF5A1F',
    kind: 'brand',
    year: '2025', // RELLENO
    es: {
      type: 'Branding · Cafetería',
      role: 'Estrategia y diseño de marca', // RELLENO
      deliverables: 'Identidad, empaques, señalética y redes', // RELLENO
      tagline: 'Branding de una cafetería moderna, joven y premium.',
      headline: 'Café para quedarse un *rato* más.', // RELLENO
      challenge: {
        title: 'Premium sin ser *frío*.', // RELLENO
        text: 'Cuenta aquí el reto de Nubla: el público, la competencia y lo que la marca tenía que lograr.', // RELLENO
        points: [['El público', 'A quién le habla Nubla.'], ['La competencia', 'Qué hacen las demás cafeterías.'], ['La meta', 'Qué tenía que lograr la marca.']] // RELLENO
      },
      research: {
        title: 'Lo que *encontré*.', text: 'Benchmark, moodboards o entrevistas.', label: 'Hallazgos', // RELLENO
        bullets: ['Hallazgo 1.', 'Hallazgo 2.', 'Hallazgo 3.'], // RELLENO
        persona: { name: 'Cliente ideal', about: 'Quién es.', wants: 'Qué busca en un café.', blocks: 'Qué lo aleja.' } // RELLENO
      },
      decisions: { title: 'Decisiones de *marca*.', items: [['El nombre', 'Por qué Nubla.'], ['El símbolo', 'Qué representa.'], ['La paleta', 'Por qué el naranja incandescente.']] }, // RELLENO
      design: { title: 'La marca en la *calle*.', text: 'Describe el sistema: logo, tipografía, color, empaques.', captions: ['Afiche 1', 'Afiche 2', 'Afiche 3'] }, // RELLENO
      result: { title: 'Resultado.', text: 'Cuenta cómo quedó la marca aplicada.', next: 'Qué sigue para Nubla.' }, // RELLENO
      stats: [['00', 'piezas diseñadas'], ['00', 'aplicaciones de marca'], ['00', 'tu métrica real']] // RELLENO
    },
    en: {
      type: 'Branding · Coffee shop',
      role: 'Brand strategy and design',
      deliverables: 'Identity, packaging, signage and social',
      tagline: 'Branding for a modern, young and premium coffee shop.',
      headline: 'Coffee to stay a little *longer*.',
      challenge: { title: 'Premium without being *cold*.', text: 'Describe the Nubla challenge here.', points: [['The audience', 'Who Nubla talks to.'], ['The competition', 'What other cafés do.'], ['The goal', 'What the brand had to achieve.']] },
      research: { title: 'What I *found*.', text: 'Benchmark, moodboards or interviews.', label: 'Findings', bullets: ['Finding 1.', 'Finding 2.', 'Finding 3.'], persona: { name: 'Ideal customer', about: 'Who they are.', wants: 'What they look for.', blocks: 'What pushes them away.' } },
      decisions: { title: 'Brand *decisions*.', items: [['The name', 'Why Nubla.'], ['The symbol', 'What it stands for.'], ['The palette', 'Why incandescent orange.']] },
      design: { title: 'The brand on the *street*.', text: 'Describe the system: logo, type, color, packaging.', captions: ['Poster 1', 'Poster 2', 'Poster 3'] },
      result: { title: 'Outcome.', text: 'Tell how the brand came to life.', next: 'What is next for Nubla.' },
      stats: [['00', 'pieces designed'], ['00', 'brand applications'], ['00', 'your real metric']]
    },
    cover: null, // RELLENO
    screens: [null, null, null], // RELLENO: afiches o piezas (se cuelgan en la pared acanalada)
    gallery: [
      { src: null, label: 'Empaque', alt: 'Vaso y bolsa de café de Nubla', size: 'tall' },
      { src: null, label: 'Señalética', alt: 'Fachada de Nubla', size: 'wide' },
      { src: null, label: 'Redes', alt: 'Publicación de Nubla en redes', size: 'sq' },
      { src: null, label: 'Menú', alt: 'Menú de Nubla', size: 'sq' }
    ]
  }
]

export const getCase = slug => cases.find(c => c.slug === slug)
