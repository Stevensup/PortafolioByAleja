import { useLayoutEffect, useRef } from 'react'
import { cases } from '../data/cases'
import { useLang, Rich } from '../lib/i18n'
import { gsap, reduced } from '../lib/motion'
import { Phone, Pic, Poster } from './Mockups'

// Franja en diagonal (-15°) con pantallas y piezas de los casos, superpuestas como cartas sobre una mesa.
function tiles() {
  const out = []
  cases.forEach(c => {
    c.screens.forEach((s, i) => out.push({ c, kind: c.kind === 'brand' ? 'poster' : 'phone', src: s, i }))
    c.gallery.forEach((g, i) => out.push({ c, kind: 'pic', src: g.src, label: g.label, alt: g.alt, i }))
  })
  return out
}
function Tile({ t }) {
  const common = 'shrink-0 rounded-[18px] overflow-hidden border border-white/10 shadow-[0_30px_60px_-20px_rgba(0,0,0,.9)]'
  if (t.kind === 'phone') return <Phone src={t.src} accent={t.c.accent} label={t.c.name} className={common + ' !h-[300px] md:!h-[380px] w-auto !rounded-[28px]'} />
  if (t.kind === 'poster') return <Poster src={t.src} accent={t.c.accent} name={t.c.name} label={t.c[ 'es'].type} variant={t.i} className={common + ' h-[300px] md:h-[380px] w-auto'} />
  return <div className={common + ' h-[300px] md:h-[380px] aspect-[4/5]'}><Pic src={t.src} accent={t.c.accent} label={t.c.name + ' · ' + t.label} alt={t.alt} /></div>
}

export default function DiagonalWall() {
  const { t } = useLang()
  const root = useRef(null)
  const all = tiles()
  const rows = [all.filter((_, i) => i % 2 === 0), all.filter((_, i) => i % 2 === 1)]
  useLayoutEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      gsap.utils.toArray('.wall-row').forEach((r, i) => {
        gsap.fromTo(r, { xPercent: i % 2 ? -18 : -4 }, { xPercent: i % 2 ? -4 : -18, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top bottom', end: 'bottom top', scrub: .6 } })
      })
    }, root)
    return () => ctx.revert()
  }, [])
  return (
    <section ref={root} className="relative py-16 md:py-24 overflow-hidden" aria-labelledby="wall-title">
      <div className="wrap mb-10">
        <p className="eyebrow">{t.wall.eyebrow}</p>
        <h2 id="wall-title" className="display h-md mt-5"><Rich text={t.wall.title} /></h2>
      </div>
      <div className="relative h-[620px] md:h-[820px] overflow-hidden" aria-hidden="true">
        <div className="absolute left-1/2 top-1/2 w-[260vw] -translate-x-1/2 -translate-y-1/2 rotate-[-15deg] flex flex-col gap-6">
          {rows.map((row, i) => (
            <div key={i} className="wall-row flex gap-6 items-center">{[...row, ...row, ...row].map((tt, k) => <Tile key={k} t={tt} />)}</div>
          ))}
        </div>
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to bottom, #0A0A0A 0%, transparent 18%, transparent 82%, #0A0A0A 100%)' }} />
      </div>
    </section>
  )
}
