import { useEffect, useRef, useState } from 'react'
import { useLang, Rich } from '../lib/i18n'
import { person } from '../data/site'
import { gsap, ScrollTrigger, reduced } from '../lib/motion'
// Titular grande, correo copiable, enlaces y cinta infinita que acelera con el scroll.
export default function Contact() {
  const { t } = useLang()
  const [msg, setMsg] = useState('')
  const mail = useRef(null), track = useRef(null)
  const copy = () => {
    const ok = () => setMsg(t.contact.copied)
    const fallback = () => { const r = document.createRange(); r.selectNodeContents(mail.current); const s = getSelection(); s.removeAllRanges(); s.addRange(r); setMsg(t.contact.selected) }
    if (navigator.clipboard) navigator.clipboard.writeText(person.email).then(ok).catch(fallback); else fallback()
    setTimeout(() => setMsg(''), 2200)
  }
  useEffect(() => {
    if (reduced) return
    const tw = gsap.to(track.current, { xPercent: -50, repeat: -1, duration: 26, ease: 'none' })
    let ts = 1, target = 1
    const st = ScrollTrigger.create({ start: 0, end: 'max', onUpdate: s => { target = s.direction * (1 + Math.min(Math.abs(s.getVelocity()) / 260, 7)) } })
    const tick = () => { ts += (target - ts) * .08; target += (Math.sign(target) - target) * .04; tw.timeScale(ts) }
    gsap.ticker.add(tick)
    return () => { gsap.ticker.remove(tick); st.kill(); tw.kill() }
  }, [])
  const words = [...t.contact.marquee, ...t.contact.marquee]
  return (
    <section id="contacto" className="relative pt-20 md:pt-32 scroll-mt-20">
      <div className="wrap">
        <p className="eyebrow">{t.contact.eyebrow}</p>
        <h2 className="display h-xl mt-6 max-w-[14ch]"><Rich text={t.contact.title} /></h2>
        <div className="mt-12 flex flex-wrap items-center gap-3">
          <code ref={mail} className="font-sans text-[clamp(18px,2.4vw,28px)] rounded-full border border-white/15 px-6 py-3 select-all">{person.email}</code>
          <button type="button" onClick={copy} className="btn btn-solid !min-h-[56px]">{t.contact.copy}</button>
          {person.links.map(l => <a key={l.label} href={l.href} target="_blank" rel="noopener" className="btn btn-ghost !min-h-[56px]">{l.label} ↗</a>)}
          <span role="status" aria-live="polite" className="text-[14px] accent-text w-full sm:w-auto">{msg}</span>
        </div>
      </div>
      <div className="marquee mt-20 md:mt-28 border-y border-white/10 py-6" aria-hidden="true">
        <div ref={track} className="marquee-track">
          {[0, 1].map(k => (
            <span key={k} className="inline-flex">
              {words.map((w, i) => (
                <span key={i} className="inline-flex items-center gap-[.35em] pr-[.35em] display text-[clamp(64px,12vw,190px)]">
                  <span className={i % 2 ? 'serif accent-text' : ''}>{w}</span><span className="w-[.22em] h-[.22em] rounded-full bg-accent inline-block" />
                </span>
              ))}
            </span>
          ))}
        </div>
      </div>
      <footer className="wrap flex flex-wrap justify-between gap-4 py-8 text-[13px] text-white/45">
        <span>© {new Date().getFullYear()} {person.name}</span><span>{t.footer}</span><a href="#" className="hover:text-white">↑</a>
      </footer>
    </section>
  )
}
