import { useLayoutEffect, useRef } from 'react'
import { useLang } from '../lib/i18n'
import { gsap, ScrollTrigger, reduced } from '../lib/motion'
// Lista enorme: la palabra que pasa por el centro de la pantalla se ilumina en blanco.
export default function Services() {
  const { t } = useLang()
  const root = useRef(null)
  useLayoutEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      gsap.utils.toArray('.svc').forEach(el => ScrollTrigger.create({ trigger: el, start: 'top 58%', end: 'bottom 42%', toggleClass: 'on' }))
    }, root)
    return () => ctx.revert()
  }, [t])
  return (
    <section ref={root} className="relative py-20 md:py-32" aria-labelledby="svc-title">
      <div className="wrap">
        <p id="svc-title" className="eyebrow mb-8">{t.services.eyebrow}</p>
        <ul className="grid">
          {t.services.items.map(s => (
            <li key={s} className={'svc group flex items-baseline gap-4 md:gap-8 border-t border-white/10 py-3 md:py-4 ' + (reduced ? 'on' : '')}>
              <span className="display text-[clamp(48px,10vw,150px)] text-[#4d4d4d] transition-colors duration-500 [.on>&]:text-fg">{s}</span>
              <span className="ml-auto w-3 h-3 rounded-full bg-accent opacity-0 transition-opacity duration-500 [.on>&]:opacity-100 shadow-[0_0_20px_var(--accent)]" aria-hidden="true" />
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
