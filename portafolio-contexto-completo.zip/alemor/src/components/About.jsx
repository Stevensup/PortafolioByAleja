import { useLayoutEffect, useRef } from 'react'
import { useLang, Rich } from '../lib/i18n'
import { person } from '../data/site'
import { gsap, reduced } from '../lib/motion'
// Foto con motion blur (capas fantasma que se juntan al entrar) y una franja de vidrio estriado.
export default function About() {
  const { t } = useLang()
  const root = useRef(null)
  useLayoutEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      gsap.fromTo('.ghost', { x: i => (i + 1) * 26, opacity: .55 }, { x: 0, opacity: 0, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top 80%', end: 'center 50%', scrub: true } })
      gsap.fromTo('.glass', { xPercent: 0 }, { xPercent: 60, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top bottom', end: 'bottom top', scrub: true } })
    }, root)
    return () => ctx.revert()
  }, [])
  return (
    <section ref={root} id="sobre-mi" className="relative py-20 md:py-32 scroll-mt-20">
      <div className="wrap grid gap-12 md:grid-cols-[1fr_1.1fr] items-center">
        <figure className="relative m-0 rounded-[24px] overflow-hidden aspect-[4/5] border border-white/10 card-glow group">
          <img src={person.photo} alt={'Retrato de ' + person.name} className="absolute inset-0 w-full h-full object-cover object-[50%_30%]" />
          {[0, 1, 2].map(i => <img key={i} src={person.photo} alt="" aria-hidden="true" className={'ghost absolute inset-0 w-full h-full object-cover object-[50%_30%] mix-blend-screen ' + (reduced ? 'hidden' : '')} style={{ filter: 'blur(3px)', opacity: 0 }} />)}
          <div className="glass absolute top-0 bottom-0 left-[-10%] w-[34%] striated" aria-hidden="true" />
          <figcaption className="absolute left-4 bottom-4 pill bg-ink/60 backdrop-blur-md text-[13px]">{person.city}</figcaption>
        </figure>
        <div>
          <p className="eyebrow">{t.about.eyebrow}</p>
          <h2 className="display h-lg mt-5"><Rich text={t.about.title} /></h2>
          <p className="mt-8 text-[clamp(17px,1.5vw,20px)] text-white/70 leading-relaxed max-w-[56ch]">{t.about.text}</p>
          <dl className="mt-10 grid sm:grid-cols-2 border-t border-white/10">
            {t.about.facts.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-4 border-b border-white/10 sm:pr-6"><dt className="text-white/50">{k}</dt><dd className="m-0 text-right">{v}</dd></div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
