import { inkOn } from '../lib/color'
// Si hay imagen la muestra; si no, dibuja un relleno con el color del caso. Así nunca queda un hueco.

export function Phone({ src, accent, label, alt = '', className = '', style }) {
  return (
    <div className={'phone ' + className} style={{ ...style, '--c': accent }}>
      {src ? <img src={src} alt={alt} loading="lazy" draggable="false" /> : (
        <div className="ph-ui" aria-hidden="true">
          {label && <span className="tag">{label}</span>}
          <div className="bar" style={{ width: '40%' }} /><div className="hero" />
          <div className="row"><i /><b /></div><div className="row"><i /><b /></div><div className="row"><i /><b /></div>
          <div className="cta" />
        </div>
      )}
    </div>
  )
}

export function Poster({ src, accent, name, label, variant = 0, alt = '', className = '' }) {
  const v = ['', 'v2', 'v3'][variant % 3]
  return (
    <div className={'poster ' + className}>
      {src ? <img src={src} alt={alt} loading="lazy" className="w-full h-full object-cover" /> : (
        <div className={'poster-ph ' + v} style={{ '--c': accent, '--ink': inkOn(accent) }} aria-hidden="true">
          <small>{label}</small><span className="ring" /><b>{name}</b>
        </div>
      )}
    </div>
  )
}

export function Pic({ src, accent, label, alt = '', className = '', imgClass = '' }) {
  return src
    ? <img src={src} alt={alt} loading="lazy" className={'w-full h-full object-cover ' + imgClass} />
    : <div className={'ph-img w-full h-full ' + className} style={{ '--c': accent }} role="img" aria-label={alt}><span>{label}</span></div>
}
