// Fondo fijo: tres luces difusas con los acentos, barras de luz verticales y grano.
export default function Background() {
  return (
    <div className="bg" aria-hidden="true">
      <div className="blob b1" /><div className="blob b2" /><div className="blob b3" />
      <div className="streaks">{Array.from({ length: 9 }).map((_, i) => <i key={i} />)}</div>
    </div>
  )
}
