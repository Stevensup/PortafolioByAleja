import { useLayoutEffect, useRef, useState, useEffect } from 'react'
import { gsap, reduced, finePointer } from '../lib/motion'
import { useLang } from '../lib/i18n'
import { person } from '../data/site'

const Spark = () => (
  <svg viewBox="0 0 24 24" className="w-[48%] h-[48%]" aria-hidden="true"><path fill="var(--accent-ink)" d="M12 1.5l2.4 7.1 7.1 2.4-7.1 2.4L12 22.5l-2.4-7.1-7.1-2.4 7.1-2.4z" /></svg>
)

function Piece({ p }) {
  const base = 'piece relative z-[1] inline-flex items-center justify-center rounded-full h-[1.14em] will-change-transform select-none'
  if (p.type === 'photo') return <span className={base + ' aspect-square overflow-hidden border border-white/15'} data-depth="1.6"><img src={person.photo} alt={person.name} className="w-full h-full object-cover object-[50%_35%] scale-[1.35]" /></span>
  if (p.type === 'icon') return <span className={base + ' aspect-square bg-accent'} data-depth="1.8"><Spark /></span>
  if (p.type === 'fill') return <span className={base + ' px-[.34em] bg-accent text-[color:var(--accent-ink)]'} data-depth="1.2">{p.text}</span>
  if (p.type === 'pill') return <span className={base + ' px-[.34em] border border-white/20 bg-ink/40 backdrop-blur-sm'} data-depth="1">{p.text}</span>
  if (p.type === 'serif') return <span className={base + ' serif px-[.05em]'} data-depth=".8">{p.text}</span>
  return <span className={base + ' px-[.04em]'} data-depth=".6">{p.text}</span>
}

// Cursores multijugador que se mueven solos, como en Figma.
function FakeCursor({ name, color, ink, bounds, start }) {
  const ref = useRef(null)
  useEffect(() => {
    if (reduced) return
    const el = ref.current
    let alive = true
    const hop = () => {
      if (!alive || !bounds.current) return
      const b = bounds.current.getBoundingClientRect()
      gsap.to(el, { x: gsap.utils.random(b.width * .05, b.width * .85), y: gsap.utils.random(b.height * .05, b.height * .8), duration: gsap.utils.random(2.2, 3.6), ease: 'sine.inOut', onComplete: hop })
    }
    const id = setTimeout(hop, start)
    return () => { alive = false; clearTimeout(id); gsap.killTweensOf(el) }
  }, [bounds, start])
  return (
    <div ref={ref} className="absolute left-0 top-0 z-[2] pointer-events-none hidden sm:block" aria-hidden="true" style={{ transform: `translate(${start / 8}px, ${start / 14}px)` }}>
      <svg width="22" height="22" viewBox="0 0 24 24"><path d="M3 2l7.5 19 2.6-7.9L21 10.5z" fill={color} stroke="#0A0A0A" strokeWidth="1.2" strokeLinejoin="round" /></svg>
      <span className="ml-4 -mt-1 inline-block rounded-full px-2.5 py-1 text-[12px] font-medium" style={{ background: color, color: ink }}>{name}</span>
    </div>
  )
}

export default function Hero() {
  const { t } = useLang()
  const h = t.hero
  const root = useRef(null), head = useRef(null), svg = useRef(null)
  const [path, setPath] = useState('')

  // Línea punteada que conecta las piezas, recalculada con el tamaño de la pantalla
  useLayoutEffect(() => {
    const draw = () => {
      if (!head.current) return
      const box = head.current.getBoundingClientRect()
      const pts = [...head.current.querySelectorAll('.piece')].map(el => { const r = el.getBoundingClientRect(); return [r.left - box.left + r.width / 2, r.top - box.top + r.height / 2] })
      setPath(pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' '))
    }
    draw(); document.fonts?.ready.then(draw)
    addEventListener('resize', draw); return () => removeEventListener('resize', draw)
  }, [h.pieces])

  // Entrada pieza por pieza + reacción al mouse
  useLayoutEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      gsap.from('.piece', { y: 60, scale: .7, rotate: i => (i % 2 ? 10 : -10), opacity: 0, duration: .9, stagger: .07, ease: 'back.out(1.7)', delay: .15 })
      gsap.fromTo('.hero-line', { strokeDashoffset: 2400 }, { strokeDashoffset: 0, duration: 2.2, ease: 'power2.out', delay: .5 })
      gsap.from('.hero-rise', { y: 24, opacity: 0, duration: .9, stagger: .08, ease: 'power3.out', delay: .7 })
    }, root)
    let off = () => {}
    if (finePointer) {
      const pieces = [...head.current.querySelectorAll('.piece')].map(el => ({ el, d: +el.dataset.depth || 1, x: gsap.quickTo(el, 'x', { duration: .8, ease: 'power3' }), y: gsap.quickTo(el, 'y', { duration: .8, ease: 'power3' }), r: gsap.quickTo(el, 'rotate', { duration: .8, ease: 'power3' }) }))
      const move = e => {
        pieces.forEach(p => {
          const b = p.el.getBoundingClientRect(), dx = e.clientX - (b.left + b.width / 2), dy = e.clientY - (b.top + b.height / 2)
          const dist = Math.hypot(dx, dy), f = Math.max(0, 1 - dist / 520)
          p.x(-dx * .06 * p.d * f); p.y(-dy * .06 * p.d * f); p.r(gsap.utils.clamp(-8, 8, dx * .02 * f))
        })
      }
      const leave = () => pieces.forEach(p => { p.x(0); p.y(0); p.r(0) })
      root.current.addEventListener('pointermove', move); root.current.addEventListener('pointerleave', leave)
      off = () => { root.current?.removeEventListener('pointermove', move); root.current?.removeEventListener('pointerleave', leave) }
    }
    return () => { off(); ctx.revert() }
  }, [h.pieces])

  return (
    <section ref={root} id="inicio" className="relative pt-32 md:pt-44 pb-16 md:pb-24">
      <div className="wrap relative">
        <p className="hero-rise eyebrow mb-8">{person.name} · {h.tags[1]} &amp; {h.tags[0]} · {person.city}</p>
        <div className="relative">
          <h1 ref={head} className="relative display text-[clamp(42px,8.2vw,120px)] flex flex-wrap items-center gap-x-[.16em] gap-y-[.14em] max-w-[13ch] sm:max-w-none">
            <svg ref={svg} className="absolute inset-0 w-full h-full overflow-visible pointer-events-none" aria-hidden="true">
              <defs><mask id="hero-mask" maskUnits="userSpaceOnUse"><path className="hero-line" d={path} fill="none" stroke="#fff" strokeWidth="8" strokeDasharray="2400" strokeDashoffset={reduced ? 0 : 2400} /></mask></defs>
              <path d={path} fill="none" stroke="rgba(255,255,255,.3)" strokeWidth="1.5" strokeDasharray="4 7" mask="url(#hero-mask)" />
            </svg>
            <span className="sr-only">{h.pieces.filter(p => p.text).map(p => p.text).join(' ')}</span>
            {h.pieces.map((p, i) => <Piece key={i} p={p} />)}
          </h1>
          <FakeCursor name={h.cursors[0]} color="#2B4BFF" ink="#fff" bounds={head} start={900} />
          <FakeCursor name={h.cursors[1]} color="#FF5A1F" ink="#0A0A0A" bounds={head} start={1500} />
        </div>
        <div className="mt-12 md:mt-16 grid gap-10 md:grid-cols-[1.2fr_1fr] items-end">
          <div className="grid gap-6">
            <p className="hero-rise text-[clamp(18px,1.7vw,22px)] text-white/75 max-w-[46ch] leading-snug">{h.intro}</p>
            <ul className="hero-rise flex flex-wrap gap-2" aria-label="Habilidades">{h.tags.map(x => <li key={x} className="pill">{x}</li>)}</ul>
            <div className="hero-rise flex flex-wrap gap-3">
              <a href="#trabajo" className="btn btn-solid">{h.primary} ↓</a>
              {person.cv && <a href={person.cv} className="btn btn-ghost" target="_blank" rel="noopener">{h.secondary}</a>}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {h.metrics.map(m => (
              <div key={m.label} className="hero-rise card card-glow p-5 md:p-6">
                <b className="block font-normal text-[clamp(48px,5.6vw,80px)] leading-none tracking-[-0.05em] accent-text">{m.value}</b>
                <span className="block mt-3 text-[14px] text-white/60 leading-snug">{m.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
