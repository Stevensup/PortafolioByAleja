import { useEffect, useRef } from 'react'
import { gsap, finePointer, reduced } from '../lib/motion'
// Cursor propio: punto que crece sobre enlaces y muestra una etiqueta donde hay data-cursor="Ver caso", "Arrastrar"...
export default function Cursor() {
  const ref = useRef(null)
  useEffect(() => {
    if (!finePointer || reduced) return
    const el = ref.current, label = el.querySelector('span')
    document.documentElement.classList.add('has-cursor')
    const x = gsap.quickTo(el, 'x', { duration: .35, ease: 'power3' }), y = gsap.quickTo(el, 'y', { duration: .35, ease: 'power3' })
    const move = e => { x(e.clientX); y(e.clientY) }
    const over = e => {
      const tagged = e.target.closest('[data-cursor]')
      el.classList.toggle('label', !!tagged)
      el.classList.toggle('link', !tagged && !!e.target.closest('a,button,input,label'))
      if (tagged) label.textContent = tagged.dataset.cursor
    }
    addEventListener('pointermove', move); document.addEventListener('pointerover', over)
    return () => { removeEventListener('pointermove', move); document.removeEventListener('pointerover', over); document.documentElement.classList.remove('has-cursor') }
  }, [])
  return <div ref={ref} className="cursor" aria-hidden="true"><span /></div>
}
