import { useLayoutEffect, useRef } from 'react'
import { useLang, Rich } from '../lib/i18n'
import { gsap, reduced } from '../lib/motion'
// Carrusel horizontal que avanza con el scroll vertical (desktop). En celular se desliza con el dedo.
const ICONS = [
  'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zm9 16-4.3-4.3',
  'M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z',
  'M4 20l4-1 11-11-3-3L5 16zM14 6l3 3',
  'M4 12l5 5L20 6',
  'M4 7l8-4 8 4-8 4zM4 12l8 4 8-4M4 17l8 4 8-4'
]
export default function Process() {
  const { t } = useLang()
  const root = useRef(null), track = useRef(null)
  useLayoutEffect(() => {
    if (reduced) return
    const mm = gsap.matchMedia()
    mm.add('(min-width: 900px)', () => {
      const dist = () => Math.max(0, track.current.scrollWidth - innerWidth + 40)
      gsap.to(track.current, { x: () => -dist(), ease: 'none', scrollTrigger: { trigger: root.current, start: 'top top', end: () => '+=' + dist(), scrub: .8, pin: true, invalidateOnRefresh: true, anticipatePin: 1 } })
    })
    return () => mm.revert()
  }, [t])
  return (
    <section ref={root} id="proceso" className="relative py-20 md:py-0 md:h-screen md:flex md:flex-col md:justify-center overflow-hidden scroll-mt-20">
      <div className="wrap mb-10 md:mb-12">
        <p className="eyebrow">{t.process.eyebrow}</p>
        <h2 className="display h-lg mt-5"><Rich text={t.process.title} /></h2>
      </div>
      <ol ref={track} className="flex gap-4 md:gap-6 px-5 md:pl-[max(20px,calc((100vw-1280px)/2+20px))] md:pr-[10vw] overflow-x-auto md:overflow-visible snap-x snap-mandatory [scrollbar-width:none] md:w-max">
        {t.process.steps.map((s, i) => (
          <li key={s.name} className="card card-glow snap-start shrink-0 w-[78vw] sm:w-[360px] md:w-[400px] min-h-[340px] p-7 md:p-8 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-[13px] tabular-nums text-white/45">{String(i + 1).padStart(2, '0')} / {String(t.process.steps.length).padStart(2, '0')}</span>
              <span className="w-12 h-12 rounded-full grid place-items-center border border-white/10">
                <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="var(--accent-text)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={ICONS[i % ICONS.length]} /></svg>
              </span>
            </div>
            <h3 className="mt-auto display text-[clamp(40px,4vw,60px)]">{s.name}</h3>
            <p className="mt-3 text-white/65 leading-relaxed">{s.text}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}
