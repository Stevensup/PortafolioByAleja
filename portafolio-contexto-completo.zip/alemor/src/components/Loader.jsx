import { useLayoutEffect, useRef } from 'react'
import { gsap } from '../lib/motion'
// Loader de ~1.3 s: el nombre se arma con piezas tipo cápsula y la cortina sube.
const PIECES = [['A', 'fill'], ['le', 'pill'], ['ja', 'text'], ['ndra', 'pill']]
export default function Loader({ onDone }) {
  const ref = useRef(null)
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.timeline({ onComplete: onDone })
        .from('.ld-piece', { yPercent: 120, rotate: i => (i % 2 ? 8 : -8), opacity: 0, duration: .5, stagger: .09, ease: 'back.out(1.6)' })
        .to('.ld-bar i', { scaleX: 1, duration: .55, ease: 'power2.inOut' }, 0)
        .to(ref.current, { yPercent: -100, duration: .55, ease: 'expo.inOut' }, '+=.12')
    }, ref)
    return () => ctx.revert()
  }, [onDone])
  return (
    <div ref={ref} className="fixed inset-0 z-[100] bg-ink flex flex-col items-center justify-center gap-8" role="status" aria-label="Cargando">
      <div className="flex items-center gap-2 text-[clamp(40px,9vw,96px)] leading-none tracking-[-0.05em]">
        {PIECES.map(([t, k], i) => (
          <span key={i} className={'ld-piece inline-flex items-center rounded-full px-[.28em] py-[.08em] ' + (k === 'fill' ? 'bg-accent text-ink' : k === 'pill' ? 'border border-white/20' : 'serif')}>{t}</span>
        ))}
      </div>
      <div className="ld-bar w-40 h-px bg-white/10 overflow-hidden"><i className="block h-full bg-accent origin-left scale-x-0" /></div>
    </div>
  )
}
