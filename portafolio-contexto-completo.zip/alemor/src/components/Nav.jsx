import { useEffect, useState } from 'react'
import { useLang } from '../lib/i18n'
import { person } from '../data/site'

// Logo a la izquierda, menú en cápsula al centro, "Hablemos" a la derecha. Se encoge al bajar.
export default function Nav({ compact = false }) {
  const { t, lang, setLang } = useLang()
  const [small0, setSmall] = useState(false)
  const small = compact || small0
  const [open, setOpen] = useState(false)
  useEffect(() => { const on = () => setSmall(scrollY > 40); on(); addEventListener('scroll', on, { passive: true }); return () => removeEventListener('scroll', on) }, [])
  const links = [['trabajo', t.nav.work], ['sobre-mi', t.nav.about], ['proceso', t.nav.process], ['contacto', t.nav.contact]]
  const LangBtn = ({ cls = '' }) => (
    <button type="button" onClick={() => setLang(lang === 'es' ? 'en' : 'es')} className={'pill !py-2 !px-3 text-[13px] hover:border-white/30 ' + cls}
      aria-label={lang === 'es' ? 'Switch to English' : 'Cambiar a español'}>{t.lang}</button>
  )
  return (
    <header className="fixed left-0 right-0 z-50" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
      <div className={'wrap flex items-center justify-between transition-all duration-500 ' + (small ? 'h-16' : 'h-20 md:h-24')}>
        <a href="#" aria-label={person.name + ', inicio'} className="flex items-center gap-3 shrink-0">
          <img src={person.monogram} alt="" className={'w-auto transition-all duration-500 ' + (small ? 'h-6' : 'h-7')} />
        </a>
        <nav aria-label="Principal" className={'hidden md:flex items-center gap-1 rounded-full border border-white/10 bg-black/40 backdrop-blur-xl transition-all duration-500 ' + (small ? 'p-1' : 'p-1.5')}>
          {links.map(([id, label]) => (
            <a key={id} href={'#' + id} className={'rounded-full text-[14px] text-white/70 hover:text-white hover:bg-white/10 transition-all ' + (small ? 'px-3.5 py-1.5' : 'px-4 py-2')}>{label}</a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <LangBtn cls="hidden sm:inline-flex" />
          <a href="#contacto" className="btn btn-solid hidden sm:inline-flex !min-h-[40px] !px-5">{t.nav.cta}</a>
          <button type="button" className="md:hidden pill !py-2" onClick={() => setOpen(true)} aria-expanded={open} aria-controls="menu-movil">{t.nav.menu}</button>
        </div>
      </div>
      {open && (
        <div id="menu-movil" className="fixed inset-0 z-50 bg-ink/95 backdrop-blur-xl flex flex-col" role="dialog" aria-modal="true" aria-label={t.nav.menu}>
          <div className="wrap h-20 flex items-center justify-between">
            <img src={person.monogram} alt="" className="h-7 w-auto" />
            <button type="button" className="pill !py-2" onClick={() => setOpen(false)}>{t.nav.close}</button>
          </div>
          <nav className="wrap flex-1 flex flex-col justify-center gap-2" aria-label="Móvil">
            {links.map(([id, label]) => <a key={id} href={'#' + id} onClick={() => setOpen(false)} className="display text-[56px] py-1">{label}</a>)}
          </nav>
          <div className="wrap pb-10 flex gap-3"><LangBtn /><a href="#contacto" onClick={() => setOpen(false)} className="btn btn-solid flex-1">{t.nav.cta}</a></div>
        </div>
      )}
    </header>
  )
}
