import { useCallback, useEffect, useState } from 'react'
import { LangProvider } from './lib/i18n'
import { useRoute } from './lib/router'
import { initLenis, scrollToId, scrollTop, ScrollTrigger, reduced } from './lib/motion'
import Background from './components/Background'
import Cursor from './components/Cursor'
import Nav from './components/Nav'
import Loader from './components/Loader'
import Home from './pages/Home'
import CaseStudy from './pages/CaseStudy'

const seen = () => { try { return sessionStorage.getItem('alemor-loaded') === '1' } catch { return false } }

export default function App() {
  const route = useRoute()
  const [loading, setLoading] = useState(() => !reduced && !seen())
  const done = useCallback(() => { setLoading(false); try { sessionStorage.setItem('alemor-loaded', '1') } catch {} }, [])

  useEffect(() => { initLenis() }, [])

  // Al cambiar de página: arriba en los casos; en la home, a la sección pedida.
  const key = route.page === 'case' ? route.c.slug : 'home'
  useEffect(() => {
    if (route.page === 'case') scrollTop()
    else if (route.section) requestAnimationFrame(() => scrollToId(route.section, true))
    else scrollTop()
    const id = setTimeout(() => ScrollTrigger.refresh(), 120)
    return () => clearTimeout(id)
  }, [key]) // eslint-disable-line

  // Enlaces internos de la home: scroll suave sin cambiar de página
  useEffect(() => {
    const on = e => {
      const a = e.target.closest('a[href^="#"]'); if (!a || e.defaultPrevented) return
      const id = a.getAttribute('href').slice(1)
      if (!id && route.page === 'home') { e.preventDefault(); scrollToId('inicio'); return }
      if (route.page === 'home' && id && document.getElementById(id)) { e.preventDefault(); scrollToId(id) }
    }
    document.addEventListener('click', on)
    return () => document.removeEventListener('click', on)
  }, [route.page])

  return (
    <LangProvider>
      <a href="#trabajo" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] btn btn-solid">Ir a los casos</a>
      <Background />
      <Cursor />
      <Nav compact={route.page === 'case'} />
      {route.page === 'case' ? <CaseStudy key={route.c.slug} c={route.c} /> : <Home />}
      {loading && <Loader onDone={done} />}
    </LangProvider>
  )
}
