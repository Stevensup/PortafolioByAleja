// Convierte dist/index.html en una página publicable como Artifact (sin <html>/<head>/<body>).
import { readFileSync, writeFileSync } from 'node:fs'
const html = readFileSync('dist/index.html', 'utf8')
const head = html.match(/<head>([\s\S]*?)<\/head>/)[1]
const body = html.match(/<body>([\s\S]*?)<\/body>/)[1]
const keep = head.split('\n').map(l => l.trim()).filter(l => /^<(title|link|script|meta name="description")/.test(l))
const out = ['<title>Alejandra Moreno</title>', '<meta name="claude:viewport-fit-sides" content="cover">', ...keep.filter(l => !l.startsWith('<title')), body.trim()].join('\n')
writeFileSync('dist/artifact.html', out + '\n')
console.log(out.slice(0, 900))
