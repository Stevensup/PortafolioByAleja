# Portafolio · Alejandra Moreno

React + Vite + Tailwind + GSAP/ScrollTrigger + Lenis.

## Correr
```
npm install
npm run dev      # http://localhost:5173
npm run build    # genera /dist para Vercel, Netlify o cualquier hosting estático
```

## Editar contenido (sin tocar componentes)
| Qué | Archivo |
|---|---|
| Textos de la home en español e inglés, correo, links, CV | `src/data/site.js` |
| Casos: textos, color, año, cifras, imágenes | `src/data/cases.js` |
| Imágenes | `public/img/<caso>/` y luego la ruta en `cases.js` |

- `*palabra*` en cualquier texto = serif itálica.
- Si una imagen es `null`, se dibuja un mockup de relleno con el color del caso.
- Busca `// RELLENO` para ver todo lo provisional.
- Para agregar o quitar un caso, agrega o borra su bloque en `cases.js`: las cartas, la franja diagonal y el "siguiente caso" se actualizan solos.

## Estructura
- `src/pages/Home.jsx`, `src/pages/CaseStudy.jsx` (plantilla de caso, 8 láminas)
- `src/components/` una pieza por sección (Hero, CaseCards, DiagonalWall, Services, Process, About, Contact, Nav, Loader, Cursor, Background, Mockups)
- `src/lib/` idioma, color activo, rutas por hash, animación y transición entre páginas
